import { reasons } from "@/data/site";

export default function WhyUs() {
  return (
    <section className="nova-container border-t border-nova-line py-20 md:py-28">
      <div className="grid gap-12 md:grid-cols-12">
        <div className="md:col-span-4">
          <p className="eyebrow">Why NOVA</p>
          <h2 className="display mt-5 text-[clamp(1.9rem,4vw,3.1rem)]">Built for the long run</h2>
          <p className="mt-5 text-sm leading-relaxed text-nova-muted">
            Founders come to us after a rebuild that went sideways. Here is what keeps the next one
            on the rails.
          </p>
        </div>

        <div className="md:col-span-8">
          <div className="grid gap-px overflow-hidden rounded-2xl border border-nova-line bg-nova-line/60 sm:grid-cols-2">
            {reasons.map((reason, index) => (
              <div key={reason.title} className="bg-nova-bg p-7">
                <span className="font-mono text-[11px] text-nova-accent-text">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-4 font-heading text-lg font-semibold tracking-tight text-nova-ink">
                  {reason.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-nova-muted">{reason.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}