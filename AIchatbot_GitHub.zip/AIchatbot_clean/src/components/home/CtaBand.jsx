import { Link } from "@tanstack/react-router";
import { ArrowRight, MessageSquare } from "lucide-react";

export default function CtaBand() {
  return (
    <section className="nova-container pb-24">
      <div className="relative overflow-hidden rounded-3xl border border-nova-line bg-nova-soft px-6 py-14 sm:px-12 sm:py-20">
        <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-nova-accent/15 blur-[90px]" />
        <div className="relative max-w-2xl">
          <p className="eyebrow">Next step</p>
          <h2 className="display mt-5 text-[clamp(1.9rem,4.2vw,3.2rem)]">
            Let&rsquo;s engineer what&rsquo;s next
          </h2>
          <p className="mt-5 text-sm leading-relaxed text-nova-muted sm:text-base">
            Tell us what you are building. You will get a written technical plan, a fixed-scope first
            increment and an honest timeline — usually within two working days.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/contact" className="btn-accent">
              Start a project <ArrowRight size={16} />
            </Link>
            <span className="inline-flex items-center gap-2 rounded-full border border-nova-line px-5 py-3 text-sm text-nova-muted">
              <MessageSquare size={15} className="text-nova-accent-text" />
              Or ask NOVA AI, bottom right
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}