import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { studioImage } from "@/data/site";

export default function Intro() {
  return (
    <section className="nova-container grid gap-12 border-t border-nova-line py-20 md:grid-cols-12 md:py-28">
      <div className="md:col-span-7">
        <p className="eyebrow">The studio</p>
        <h2 className="display mt-5 text-[clamp(1.9rem,4vw,3.1rem)] text-nova-ink">
          A small team that ships like a big one
        </h2>
        <p className="mt-6 max-w-xl text-base leading-relaxed text-nova-muted">
          We work with startup founders who need a real product, not a prototype that impresses in a
          pitch deck and collapses in production. Architecture, design and delivery sit in the same
          room — so decisions happen in days, not sprints of meetings.
        </p>
        <Link
          to="/about"
          className="mt-8 inline-flex items-center gap-2 text-sm font-medium text-nova-accent-text transition-opacity hover:opacity-70"
        >
          Meet the team <ArrowUpRight size={15} />
        </Link>
      </div>

      <div className="md:col-span-5">
        <div className="overflow-hidden rounded-2xl border border-nova-line">
          <Image
            src={studioImage}
            alt="Frosted glass monoliths rising in dark fog with cyan light on their edges"
            className="h-64 w-full object-cover sm:h-80"
          />
        </div>
      </div>
    </section>
  );
}