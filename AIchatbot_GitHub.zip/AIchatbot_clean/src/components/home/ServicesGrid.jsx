import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { services } from "@/data/site";

export default function ServicesGrid() {
  return (
    <section className="border-t border-nova-line bg-nova-soft/40 py-20 md:py-28">
      <div className="nova-container">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow">Capabilities</p>
            <h2 className="display mt-5 max-w-lg text-[clamp(1.9rem,4vw,3.1rem)]">What we build</h2>
          </div>
          <Link to="/services" className="btn-ghost">
            All services <ArrowUpRight size={15} />
          </Link>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Link
                key={service.id}
                to="/services"
                hash={service.id}
                className={`nova-card group relative overflow-hidden p-7 transition-colors duration-300 hover:border-nova-accent/50 ${
                  index === 0 ? "md:p-9" : ""
                }`}
              >
                <div className="flex items-start justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-xl border border-nova-line bg-nova-bg text-nova-accent-text transition-colors group-hover:border-nova-accent/60">
                    <Icon size={18} />
                  </span>
                  <span className="font-mono text-[11px] text-nova-muted">0{index + 1}</span>
                </div>
                <h3 className="mt-6 font-heading text-xl font-semibold tracking-tight text-nova-ink">
                  {service.title}
                </h3>
                <p className="mt-3 max-w-md text-sm leading-relaxed text-nova-muted">{service.summary}</p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {service.tech.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-full border border-nova-line px-3 py-1 text-[11px] uppercase tracking-[0.12em] text-nova-muted"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}