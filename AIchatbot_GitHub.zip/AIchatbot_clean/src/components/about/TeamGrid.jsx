import { team } from "@/data/site";

export default function TeamGrid() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {team.map((member) => (
        <div key={member.name} className="nova-card p-6">
          <div className="grid h-12 w-12 place-items-center rounded-full border border-nova-line bg-nova-bg font-heading text-sm font-semibold text-nova-accent-text">
            {member.name
              .split(" ")
              .map((part) => part[0])
              .join("")}
          </div>
          <h3 className="mt-5 font-heading text-base font-semibold tracking-tight text-nova-ink">
            {member.name}
          </h3>
          <p className="mt-1 text-sm text-nova-muted">{member.role}</p>
          <p className="mt-4 text-[11px] uppercase tracking-[0.14em] text-nova-accent-text">{member.focus}</p>
        </div>
      ))}
    </div>
  );
}