import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";

export default function ServiceSection({ service, index }) {
  const Icon = service.icon;
  return (
    <section id={service.id} className="scroll-mt-28 border-t border-nova-line py-14 first:border-t-0 lg:py-20">
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-nova-line bg-nova-soft text-nova-accent-text">
              <Icon size={18} />
            </span>
            <span className="font-mono text-[11px] text-nova-muted">0{index + 1}</span>
          </div>
          <h2 className="display mt-5 text-[clamp(1.6rem,3vw,2.2rem)] text-nova-ink">{service.title}</h2>
        </div>

        <div className="lg:col-span-8">
          <p className="max-w-2xl text-base leading-relaxed text-nova-ink/90">{service.summary}</p>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-nova-muted">{service.detail}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {service.tech.map((tech) => (
              <span
                key={tech}
                className="rounded-full border border-nova-line px-3 py-1 text-[11px] uppercase tracking-[0.12em] text-nova-muted"
              >
                {tech}
              </span>
            ))}
          </div>
          <Link
            to="/contact"
            className="mt-7 inline-flex items-center gap-1.5 text-sm font-medium text-nova-accent-text transition-opacity hover:opacity-70"
          >
            Talk to us about {service.title.toLowerCase()} <ArrowUpRight size={15} />
          </Link>
        </div>
      </div>
    </section>
  );
}