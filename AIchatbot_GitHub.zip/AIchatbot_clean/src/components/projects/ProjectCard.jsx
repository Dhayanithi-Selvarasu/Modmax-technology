export default function ProjectCard({ project }) {
  return (
    <article className="nova-card group flex h-full flex-col p-7 transition-colors duration-300 hover:border-nova-accent/50">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[11px] text-nova-muted">{project.year}</span>
        <span className="rounded-full border border-nova-accent/30 bg-nova-accent/10 px-3 py-1 text-[11px] font-medium text-nova-accent-text">
          {project.result}
        </span>
      </div>
      <h3 className="mt-6 font-heading text-xl font-semibold tracking-tight text-nova-ink">
        {project.name}
      </h3>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-nova-muted">{project.summary}</p>
      <div className="mt-6 flex flex-wrap gap-2">
        {project.tech.map((tech) => (
          <span
            key={tech}
            className="rounded-full border border-nova-line px-3 py-1 text-[11px] uppercase tracking-[0.12em] text-nova-muted"
          >
            {tech}
          </span>
        ))}
      </div>
    </article>
  );
}