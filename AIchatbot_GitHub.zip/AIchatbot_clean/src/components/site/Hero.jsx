import { Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles } from "lucide-react";
import { Image } from "@/components/ui/image";
import { heroImage, stats } from "@/data/site";

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <Image
          src={heroImage}
          alt="Cyan light refracting through a glass prism on black"
          className="h-full w-full object-cover opacity-45"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-nova-bg/70 via-nova-bg/85 to-nova-bg" />
        <div className="absolute left-1/2 top-[-10%] h-[460px] w-[780px] -translate-x-1/2 rounded-full bg-nova-accent/10 blur-[130px]" />
      </div>

      <div className="nova-container pb-16 pt-32 sm:pb-24 sm:pt-44">
        <div className="flex items-center gap-3">
          <span className="grid h-7 w-7 place-items-center rounded-full border border-nova-accent/40 text-nova-accent-text">
            <Sparkles size={13} />
          </span>
          <p className="eyebrow !text-nova-accent-text">Software studio for founders</p>
        </div>

        <h1 className="display mt-7 max-w-4xl text-[clamp(2.3rem,6.6vw,4.9rem)] text-nova-ink">
          Let&rsquo;s get your startup idea{" "}
          <span className="text-nova-accent-text">out into the world.</span>
        </h1>

        <p className="mt-7 max-w-xl text-base leading-relaxed text-nova-muted sm:text-lg">
          ModMax Technology is a small studio of senior engineers. We take founder ideas to a launched MVP
          fast — web apps, mobile apps, AI features and the cloud underneath them.
        </p>

        <div className="mt-9 flex flex-wrap items-center gap-3">
          <Link to="/contact" className="btn-accent">
            Start a project <ArrowRight size={16} />
          </Link>
          <Link to="/services" className="btn-ghost">
            Explore services
          </Link>
        </div>

        <dl className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-nova-line bg-nova-line/60 sm:mt-20 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-nova-bg/80 px-5 py-6 backdrop-blur-sm">
              <dt className="font-heading text-3xl font-semibold tracking-tight text-nova-ink">
                {stat.value}
              </dt>
              <dd className="mt-1 text-xs uppercase tracking-[0.18em] text-nova-muted">{stat.label}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}