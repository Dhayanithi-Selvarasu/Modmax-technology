import { Link } from "@tanstack/react-router";
import { Github, Linkedin, Mail, MoveRight, Twitter } from "lucide-react";
import { company, navLinks, services } from "@/data/site";

export default function Footer() {
  return (
    <footer className="border-t border-nova-line bg-nova-soft">
      <div className="nova-container grid gap-12 py-16 md:grid-cols-12">
        <div className="md:col-span-5">
          <div className="flex items-baseline gap-2">
            <span className="font-heading text-base font-semibold uppercase tracking-[0.26em]">ModMax</span>
            <span className="text-[10px] uppercase tracking-[0.34em] text-nova-accent-text">Technology</span>
          </div>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-nova-muted">
            A software development studio for web platforms, mobile applications, AI integration and
            cloud infrastructure.
          </p>
          <a
            href={`mailto:${company.email}`}
            className="mt-6 inline-flex items-center gap-2 text-sm text-nova-ink transition-colors hover:text-nova-accent-text"
          >
            <Mail size={15} /> {company.email}
          </a>
        </div>

        <div className="md:col-span-3">
          <p className="eyebrow">Navigate</p>
          <ul className="mt-4 space-y-2.5">
            {navLinks.map((link) => (
              <li key={link.to}>
                <Link to={link.to} className="text-sm text-nova-muted transition-colors hover:text-nova-ink">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-2">
          <p className="eyebrow">Services</p>
          <ul className="mt-4 space-y-2.5">
            {services.map((service) => (
              <li key={service.id}>
                <Link
                  to="/services"
                  hash={service.id}
                  className="text-sm text-nova-muted transition-colors hover:text-nova-ink"
                >
                  {service.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-2">
          <p className="eyebrow">Elsewhere</p>
          <div className="mt-4 flex gap-2">
            {[
              { href: "https://www.linkedin.com", label: "LinkedIn", Icon: Linkedin },
              { href: "https://github.com", label: "GitHub", Icon: Github },
              { href: "https://x.com", label: "X", Icon: Twitter },
            ].map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noreferrer"
                aria-label={label}
                className="grid h-9 w-9 place-items-center rounded-full border border-nova-line text-nova-muted transition-colors hover:border-nova-accent hover:text-nova-accent-text"
              >
                <Icon size={15} />
              </a>
            ))}
          </div>
          <a
            href={company.website}
            target="_blank"
            rel="noreferrer"
            className="mt-4 inline-flex items-center gap-1 text-xs text-nova-muted transition-colors hover:text-nova-accent-text"
          >
            modmax.com <MoveRight size={13} />
          </a>
        </div>
      </div>

      <div className="border-t border-nova-line">
        <div className="nova-container flex flex-col gap-2 py-6 text-xs text-nova-muted sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} ModMax Technology. All rights reserved.</p>
          <p>{company.location} · Software Development</p>
        </div>
      </div>
    </footer>
  );
}