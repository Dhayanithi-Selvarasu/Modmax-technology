export default function PageHeader({ eyebrow, title, intro, children }) {
  return (
    <section className="relative overflow-hidden border-b border-nova-line">
      <div className="pointer-events-none absolute -left-32 top-0 h-72 w-72 rounded-full bg-nova-accent/10 blur-[110px]" />
      <div className="nova-container relative pb-14 pt-32 sm:pb-20 sm:pt-40">
        <p className="eyebrow !text-nova-accent-text">{eyebrow}</p>
        <h1 className="display mt-5 max-w-3xl text-[clamp(2.1rem,5.6vw,4rem)] text-nova-ink">{title}</h1>
        {intro && (
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-nova-muted">{intro}</p>
        )}
        {children}
      </div>
    </section>
  );
}