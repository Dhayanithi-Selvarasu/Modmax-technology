import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { ArrowUpRight, Menu, X } from "lucide-react";
import ThemeToggle from "@/components/site/ThemeToggle";
import { navLinks } from "@/data/site";

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
        scrolled || open
          ? "border-b border-nova-line bg-nova-bg/85 backdrop-blur-xl"
          : "border-b border-transparent"
      }`}
    >
      <div className="nova-container flex h-16 items-center justify-between sm:h-20">
        <Link to="/" className="flex items-baseline gap-2">
          <span className="font-heading text-base font-semibold uppercase tracking-[0.26em] text-nova-ink">
            ModMax
          </span>
          <span className="text-[10px] uppercase tracking-[0.34em] text-nova-accent-text">Technology</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              activeProps={{ className: "text-nova-ink" }}
              inactiveProps={{ className: "text-nova-muted" }}
              activeOptions={{ exact: link.to === "/" }}
              className="rounded-full px-4 py-2 text-sm transition-colors hover:text-nova-accent-text"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link to="/contact" className="btn-accent hidden sm:inline-flex">
            Start a project <ArrowUpRight size={15} />
          </Link>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            className="grid h-10 w-10 place-items-center rounded-full border border-nova-line text-nova-ink md:hidden"
          >
            {open ? <X size={17} /> : <Menu size={17} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-nova-line bg-nova-bg/95 md:hidden">
          <div className="nova-container flex flex-col py-3">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="border-b border-nova-line/60 py-3 text-sm text-nova-ink last:border-0"
              >
                {link.label}
              </Link>
            ))}
            <Link to="/contact" className="btn-accent mt-4 mb-2">
              Start a project <ArrowUpRight size={15} />
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}