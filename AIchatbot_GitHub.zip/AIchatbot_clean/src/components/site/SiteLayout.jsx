import { Outlet } from "@tanstack/react-router";
import Nav from "@/components/site/Nav";
import Footer from "@/components/site/Footer";
import ChatWidget from "@/components/chat/ChatWidget";

export default function SiteLayout() {
  return (
    <div className="flex min-h-screen flex-col bg-nova-bg text-nova-ink">
      <Nav />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <ChatWidget />
    </div>
  );
}