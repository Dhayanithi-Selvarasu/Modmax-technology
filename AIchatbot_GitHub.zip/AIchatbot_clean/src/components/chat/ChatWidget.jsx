import { useEffect, useRef, useState } from "react";
import { ArrowUp, MessageCircle, Sparkles, Trash2, X } from "lucide-react";
import ChatMessage from "@/components/chat/ChatMessage";
import TypingIndicator from "@/components/chat/TypingIndicator";

import { sendChatMessage } from "@/lib/backend-api";

const WELCOME =
  "Hello! 👋 Welcome to ModMax Technology. I'm your AI assistant. Ask me anything about our company, services, projects or contact information.";

const SUGGESTIONS = [
  "Tell me about your company.",
  "What services do you offer?",
  "What projects have you completed?",
  "How can I contact your company?",
  "What technologies do you use?",
];

const SESSION_KEY = "nova-chat-session";

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([{ id: "welcome", role: "assistant", content: WELCOME }]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [sessionId, setSessionId] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    let id = window.sessionStorage.getItem(SESSION_KEY);
    if (!id) {
      id = crypto.randomUUID();
      window.sessionStorage.setItem(SESSION_KEY, id);
    }
    setSessionId(id);
  }, []);

  useEffect(() => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, sending, open]);

  const send = async (raw) => {
    const text = (raw ?? input).trim();
    if (!text || sending) return;

    const history = messages
      .filter((message) => message.id !== "welcome" && message.role !== "error")
      .map((message) => ({ role: message.role, content: message.content }));

    setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: "user", content: text }]);
    setInput("");
    setSending(true);

    try {
      const result = await sendChatMessage({ data: { message: text, history, sessionId } });
      const failure =
        result?.error || "The assistant could not answer that just now. Please try again in a moment.";
      setMessages((prev) => [
        ...prev,
        result?.error
          ? { id: crypto.randomUUID(), role: "error", content: failure }
          : { id: crypto.randomUUID(), role: "assistant", content: result.reply },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "error",
          content: "I could not reach the assistant just now. Please try again, or email contact@modmaxtechnologies@gmail.com.",
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const clearConversation = () => {
    const id = crypto.randomUUID();
    window.sessionStorage.setItem(SESSION_KEY, id);
    setSessionId(id);
    setMessages([{ id: "welcome", role: "assistant", content: WELCOME }]);
    setInput("");
  };

  const showSuggestions = messages.length === 1 && !sending;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label={open ? "Close ModMax AI Assistant" : "Open ModMax AI Assistant"}
        className="fixed bottom-5 right-4 z-50 grid h-14 w-14 place-items-center rounded-full bg-nova-accent text-nova-accent-ink shadow-[0_10px_40px_-8px_hsl(var(--site-accent)/0.7)] transition-transform duration-300 hover:scale-105 active:scale-95 sm:bottom-7 sm:right-6"
      >
        {open ? <X size={20} /> : <MessageCircle size={22} />}
        {!open && (
          <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-nova-accent/30" />
        )}
      </button>

      {open && (
        <div className="fixed bottom-24 right-3 z-50 flex h-[min(70vh,560px)] w-[calc(100vw-1.5rem)] max-w-[400px] animate-fade-up flex-col overflow-hidden rounded-2xl glass shadow-2xl sm:right-6">
          <div className="flex items-center justify-between gap-2 border-b border-nova-line px-4 py-3.5">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-nova-accent/15 text-nova-accent-text">
                <Sparkles size={16} />
              </span>
              <div>
                <p className="font-heading text-sm font-semibold text-nova-ink">ModMax   AI Assistant</p>
                <p className="flex items-center gap-1.5 text-[11px] text-nova-muted">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  Online · replies in seconds
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={clearConversation}
                aria-label="Clear conversation"
                title="Clear conversation"
                className="grid h-8 w-8 place-items-center rounded-full text-nova-muted transition-colors hover:bg-nova-accent/10 hover:text-nova-accent-text"
              >
                <Trash2 size={15} />
              </button>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close chat"
                className="grid h-8 w-8 place-items-center rounded-full text-nova-muted transition-colors hover:bg-nova-accent/10 hover:text-nova-accent-text"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
            {messages.map((message) => (
              <ChatMessage key={message.id} role={message.role} content={message.content} />
            ))}
            {sending && <TypingIndicator />}
          </div>

          {showSuggestions && (
            <div className="flex flex-wrap gap-1.5 border-t border-nova-line px-4 py-3">
              {SUGGESTIONS.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => send(suggestion)}
                  className="rounded-full border border-nova-line px-3 py-1.5 text-[11px] text-nova-muted transition-colors hover:border-nova-accent/60 hover:text-nova-accent-text"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}

          <form
            onSubmit={(event) => {
              event.preventDefault();
              send();
            }}
            className="flex items-center gap-2 border-t border-nova-line bg-nova-bg/60 px-3 py-3"
          >
            <input
              value={input}
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  send();
                }
              }}
              maxLength={1000}
              placeholder="Ask about ModMax Technology…"
              aria-label="Message ModMax AI Assistant"
              className="min-w-0 flex-1 bg-transparent px-2 py-2 text-sm text-nova-ink placeholder:text-nova-muted focus:outline-none"
            />
            <button
              type="submit"
              disabled={!input.trim() || sending}
              aria-label="Send message"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-nova-accent text-nova-accent-ink transition-opacity disabled:opacity-40"
            >
              <ArrowUp size={16} />
            </button>
          </form>
        </div>
      )}
    </>
  );
}