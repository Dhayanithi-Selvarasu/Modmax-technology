import ReactMarkdown from "react-markdown";
import { AlertCircle } from "lucide-react";

const markdownComponents = {
  p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
  ul: ({ children }) => <ul className="mb-2 list-disc pl-4 last:mb-0">{children}</ul>,
  ol: ({ children }) => <ol className="mb-2 list-decimal pl-4 last:mb-0">{children}</ol>,
  li: ({ children }) => <li className="mb-1">{children}</li>,
  strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
  a: ({ children, href }) => (
    <a href={href} target="_blank" rel="noreferrer" className="underline underline-offset-2">
      {children}
    </a>
  ),
};

export default function ChatMessage({ role, content }) {
  if (role === "error") {
    return (
      <div className="flex justify-start">
        <div className="flex max-w-[86%] items-start gap-2 rounded-2xl rounded-bl-md border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm leading-relaxed text-red-300">
          <AlertCircle size={15} className="mt-0.5 shrink-0" />
          <span>{content}</span>
        </div>
      </div>
    );
  }

  const isUser = role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[86%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? "rounded-br-md bg-nova-accent text-nova-accent-ink"
            : "rounded-bl-md border border-nova-line bg-nova-bg text-nova-ink"
        }`}
      >
        {isUser ? content : <ReactMarkdown components={markdownComponents}>{content}</ReactMarkdown>}
      </div>
    </div>
  );
}