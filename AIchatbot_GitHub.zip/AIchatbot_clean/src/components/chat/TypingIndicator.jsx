export default function TypingIndicator() {
  return (
    <div className="flex justify-start">
      <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-md border border-nova-line bg-nova-bg px-4 py-3">
        {[0, 1, 2].map((dot) => (
          <span
            key={dot}
            className="h-1.5 w-1.5 animate-bounce rounded-full bg-nova-accent-text"
            style={{ animationDelay: `${dot * 140}ms`, animationDuration: "900ms" }}
          />
        ))}
        <span className="sr-only">Modmax AI is typing</span>
      </div>
    </div>
  );
}