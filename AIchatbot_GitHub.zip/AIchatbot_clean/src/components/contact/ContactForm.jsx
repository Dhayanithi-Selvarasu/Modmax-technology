import { useState } from "react";
import { ArrowUpRight, CheckCircle2, Loader2 } from "lucide-react";
import { submitContactMessage } from "@/lib/backend-api";

const empty = { name: "", email: "", subject: "", message: "" };
const fieldClass =
  "w-full rounded-xl border border-nova-line bg-nova-bg px-4 py-3 text-sm text-nova-ink placeholder:text-nova-muted transition-colors focus:border-nova-accent focus:outline-none";

function validate(values) {
  const errors = {};
  if (values.name.trim().length < 2) errors.name = "Please tell us your name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim()))
    errors.email = "Enter a valid email address.";
  if (values.subject.trim().length < 2) errors.subject = "Add a short subject.";
  if (values.message.trim().length < 10) errors.message = "Tell us a little more (10+ characters).";
  return errors;
}

export default function ContactForm() {
  const [values, setValues] = useState(empty);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle");
  const [formError, setFormError] = useState("");

  const update = (field) => (event) => {
    setValues((prev) => ({ ...prev, [field]: event.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const nextErrors = validate(values);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setStatus("sending");
    setFormError("");
    try {
      await submitContactMessage({
        data: {
          name: values.name.trim(),
          email: values.email.trim(),
          subject: values.subject.trim(),
          message: values.message.trim(),
        },
      });
      setStatus("sent");
      setValues(empty);
    } catch {
      setStatus("idle");
      setFormError(
        "We could not send that just now. Please try again, or email contact@modmaxtechnologies@gmail.com directly.",
      );
    }
  };

  if (status === "sent") {
    return (
      <div className="nova-card flex flex-col items-start gap-4 p-8">
        <span className="grid h-11 w-11 place-items-center rounded-full bg-nova-accent/15 text-nova-accent-text">
          <CheckCircle2 size={20} />
        </span>
        <div>
          <h3 className="font-heading text-lg font-semibold text-nova-ink">Message received</h3>
          <p className="mt-2 text-sm leading-relaxed text-nova-muted">
            Thanks for reaching out. A senior engineer will reply within one business day — usually
            sooner.
          </p>
        </div>
        <button type="button" onClick={() => setStatus("idle")} className="btn-ghost">
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="nova-card space-y-5 p-6 sm:p-8" noValidate>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="mb-2 block text-xs uppercase tracking-[0.16em] text-nova-muted">
            Name
          </label>
          <input
            id="name"
            value={values.name}
            onChange={update("name")}
            placeholder="Your name"
            className={fieldClass}
            maxLength={80}
          />
          {errors.name && <p className="mt-1.5 text-xs text-red-400">{errors.name}</p>}
        </div>
        <div>
          <label htmlFor="email" className="mb-2 block text-xs uppercase tracking-[0.16em] text-nova-muted">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={values.email}
            onChange={update("email")}
            placeholder="you@company.com"
            className={fieldClass}
            maxLength={160}
          />
          {errors.email && <p className="mt-1.5 text-xs text-red-400">{errors.email}</p>}
        </div>
      </div>

      <div>
        <label htmlFor="subject" className="mb-2 block text-xs uppercase tracking-[0.16em] text-nova-muted">
          Subject
        </label>
        <input
          id="subject"
          value={values.subject}
          onChange={update("subject")}
          placeholder="What do you want to build?"
          className={fieldClass}
          maxLength={140}
        />
        {errors.subject && <p className="mt-1.5 text-xs text-red-400">{errors.subject}</p>}
      </div>

      <div>
        <label htmlFor="message" className="mb-2 block text-xs uppercase tracking-[0.16em] text-nova-muted">
          Message
        </label>
        <textarea
          id="message"
          value={values.message}
          onChange={update("message")}
          rows={5}
          placeholder="Tell us about the product, the timeline and where you are today."
          className={`${fieldClass} resize-none`}
          maxLength={2000}
        />
        {errors.message && <p className="mt-1.5 text-xs text-red-400">{errors.message}</p>}
      </div>

      {formError && <p className="text-xs text-red-400">{formError}</p>}

      <div className="flex flex-wrap items-center gap-4">
        <button type="submit" disabled={status === "sending"} className="btn-accent disabled:opacity-60">
          {status === "sending" ? (
            <>
              <Loader2 size={15} className="animate-spin" /> Sending
            </>
          ) : (
            <>
              Send message <ArrowUpRight size={15} />
            </>
          )}
        </button>
        <p className="text-xs text-nova-muted">We reply within one business day.</p>
      </div>
    </form>
  );
}