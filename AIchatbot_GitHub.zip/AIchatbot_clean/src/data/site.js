import { Code2, Smartphone, Sparkles, Cloud } from "lucide-react";

export const company = {
  name: "ModMax Technology",
  industry: "Software Development",
  email: "Modmaxtechnologies@gmail.com",
  website: "https://example.com",
  location: "Remote-first studio",
};

export const heroImage =
  "https://media.base44.com/images/public/6af9b288966565aeb3a64b28/f0b599459_generated_a7dd946c.png";

export const studioImage =
  "https://media.base44.com/images/public/6af9b288966565aeb3a64b28/da7ce1042_generated_22d90e64.png";

export const navLinks = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/projects", label: "Projects" },
  { to: "/contact", label: "Contact" },
];

export const stats = [
  { value: "68", label: "Products shipped" },
  { value: "12", label: "Industries served" },
  { value: "24", label: "Engineers & designers" },
  { value: "98%", label: "Client retention" },
];

export const services = [
  {
    id: "web",
    icon: Code2,
    title: "Web Development",
    summary:
      "Production-grade web platforms: React front ends, Java and Spring Boot services, and APIs built to survive real traffic.",
    detail:
      "We design and build customer-facing platforms and internal tools end to end — component libraries, authentication, payments, reporting, and the test suites that keep them stable. Every release ships with observability wired in.",
    tech: ["React", "JavaScript", "Java", "Spring Boot", "MySQL"],
  },
  {
    id: "mobile",
    icon: Smartphone,
    title: "App Development",
    summary:
      "Mobile applications that feel native, stay fast on weak networks, and share a single API with your web platform.",
    detail:
      "From field-service tools to consumer apps, we handle offline sync, push notifications, store release and long-term maintenance — with a design system that keeps iOS and Android coherent.",
    tech: ["React", "JavaScript", "Java", "REST APIs"],
  },
  {
    id: "ai",
    icon: Sparkles,
    title: "AI Integration",
    summary:
      "Gemini-powered assistants and workflow automation grounded in your own data — not a generic chatbot bolted on.",
    detail:
      "We build retrieval over your documentation, tool-calling agents that actually complete tasks, guardrails, evaluation suites and cost controls. The API key never leaves the server.",
    tech: ["Gemini API", "Spring Boot", "React", "Vector search"],
  },
  {
    id: "cloud",
    icon: Cloud,
    title: "Cloud Solutions",
    summary:
      "Infrastructure, CI/CD and monitoring that keep platforms predictable as they grow from pilot to production.",
    detail:
      "Containerised deployments, managed databases, zero-downtime releases, alerting and cost reviews. We document the runbook so your team can operate it without us.",
    tech: ["Docker", "AWS", "Google Cloud", "MySQL"],
  },
];

export const projects = [
  {
    name: "Helios Commerce",
    year: "2024",
    summary:
      "Replatformed a 40-market storefront onto a headless React front end with Spring Boot services and a MySQL catalogue.",
    result: "+38% conversion",
    tech: ["React", "Spring Boot", "MySQL"],
  },
  {
    name: "Atlas Fleet Cloud",
    year: "2024",
    summary:
      "Realtime telemetry and dispatch for 12,000 vehicles across nine depots, with a control room that never blinks.",
    result: "12,000 vehicles",
    tech: ["Java", "Spring Boot", "Google Cloud"],
  },
  {
    name: "Lumen Assist",
    year: "2025",
    summary:
      "Gemini-powered support assistant grounded in 6,000 product documents, wired through a validation layer in the backend.",
    result: "62% ticket deflection",
    tech: ["Gemini API", "Spring Boot", "React"],
  },
  {
    name: "Verso Field",
    year: "2023",
    summary:
      "Offline-first field service app for 400 technicians, syncing inspections and photos the moment signal returns.",
    result: "400 technicians",
    tech: ["React", "Java", "MySQL"],
  },
  {
    name: "Northwind Vault",
    year: "2023",
    summary:
      "Compliance-grade document archive with immutable audit trails, role-based access and signed retrieval links.",
    result: "SOC 2 ready",
    tech: ["Java", "Spring Boot", "AWS"],
  },
  {
    name: "Cobalt Analytics",
    year: "2025",
    summary:
      "Self-serve reporting layer that turns operational data into answers the whole company can read.",
    result: "9 data sources",
    tech: ["React", "Java", "Recharts"],
  },
];

export const reasons = [
  {
    title: "Senior-only delivery",
    body: "The engineers in the kickoff call are the engineers writing the code. No handoffs, no layers.",
  },
  {
    title: "Six-week increments",
    body: "Fixed-scope increments with a working demo every two weeks, so you can steer before it is expensive.",
  },
  {
    title: "Production-grade by default",
    body: "Tests, migrations, logging and access rules ship with the feature — not as a cleanup phase later.",
  },
  {
    title: "Documented handover",
    body: "Architecture notes, runbooks and a walkthrough recording, so your team owns the platform afterwards.",
  },
];

export const team = [
  { name: "Aarav Mehta", role: "Founder & Principal Engineer", focus: "Java · Spring Boot" },
  { name: "Sofia Almeida", role: "Head of Product Design", focus: "Design systems · React" },
  { name: "Daniel Okafor", role: "Cloud Architect", focus: "AWS · Observability" },
  { name: "Mei Tanaka", role: "AI Lead", focus: "Gemini · Retrieval" },
];

export const mission = {
  mission:
    "Build software that a client's own team can confidently run — clear architecture, honest estimates, and no black boxes.",
  vision:
    "A small studio where senior engineers stay close to the problems they solve, and where AI features are treated as engineering, not decoration.",
};