import { createFileRoute } from "@tanstack/react-router";
import PageHeader from "@/components/site/PageHeader";
import ProjectCard from "@/components/projects/ProjectCard";
import CtaBand from "@/components/home/CtaBand";
import { projects } from "@/data/site";

export const Route = createFileRoute("/_site/projects")({
  head: () => ({
    meta: [
      { title: "Projects — ModMax Technology" },
      {
        name: "description",
        content:
          "Selected work from ModMax Technology: commerce platforms, fleet telemetry, AI assistants and field service apps built with React, Java, Spring Boot and Gemini.",
      },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Projects"
        title="Work that made it to production."
        intro="A sample of platforms we have designed, built and launched. Each one is still running with the team that owns it."
      />

      <section className="nova-container py-16 md:py-20">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <ProjectCard key={project.name} project={project} />
          ))}
        </div>
      </section>

      <CtaBand />
    </>
  );
}