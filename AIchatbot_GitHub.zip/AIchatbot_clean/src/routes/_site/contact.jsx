import { createFileRoute } from "@tanstack/react-router";
import { Globe, Mail, MessageSquare, Timer } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import ContactForm from "@/components/contact/ContactForm";
import { company } from "@/data/site";

export const Route = createFileRoute("/_site/contact")({
  head: () => ({
    meta: [
      { title: "Contact — ModMax Technology" },
      {
        name: "description",
        content:
          "Tell ModMax Technology what you are building. Send a project brief and get a written technical plan, fixed-scope first increment and an honest timeline.",
      },
    ],
  }),
  component: ContactPage,
});

const details = [
  { Icon: Mail, label: "Email", value: company.email, href: `mailto:${company.email}` },
  { Icon: Globe, label: "Website", value: "example.com", href: company.website },
  { Icon: Timer, label: "Response time", value: "Within one business day" },
];

function ContactPage() {
  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title="Tell us what you're building."
        intro="Share the idea, the deadline and where the product stands today. You will get a written plan back — not a sales call."
      />

      <section className="nova-container py-16 md:py-20">
        <div className="grid gap-8 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <ContactForm />
          </div>

          <aside className="space-y-4 lg:col-span-5">
            <div className="nova-card p-7">
              <p className="eyebrow">Direct</p>
              <ul className="mt-5 space-y-5">
                {details.map(({ Icon, label, value, href }) => (
                  <li key={label} className="flex items-start gap-3">
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-nova-line text-nova-accent-text">
                      <Icon size={15} />
                    </span>
                    <div>
                      <p className="text-[11px] uppercase tracking-[0.16em] text-nova-muted">{label}</p>
                      {href ? (
                        <a
                          href={href}
                          target={href.startsWith("http") ? "_blank" : undefined}
                          rel="noreferrer"
                          className="text-sm text-nova-ink transition-colors hover:text-nova-accent-text"
                        >
                          {value}
                        </a>
                      ) : (
                        <p className="text-sm text-nova-ink">{value}</p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="nova-card p-7">
              <span className="grid h-9 w-9 place-items-center rounded-lg bg-nova-accent/15 text-nova-accent-text">
                <MessageSquare size={16} />
              </span>
              <h2 className="mt-4 font-heading text-base font-semibold text-nova-ink">
                Need an answer right now?
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-nova-muted">
                Ask ModMax AI Assistant in the corner of the screen — it answers questions about our
                services, projects and technologies instantly, day or night.
              </p>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}