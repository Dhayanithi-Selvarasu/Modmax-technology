import { createFileRoute } from "@tanstack/react-router";
import PageHeader from "@/components/site/PageHeader";
import TeamGrid from "@/components/about/TeamGrid";
import CtaBand from "@/components/home/CtaBand";
import { mission, stats } from "@/data/site";
import { Image } from "@/components/ui/image";

const aboutImage = "https://media.base44.com/images/public/6af9b288966565aeb3a64b28/c9749400f_generated_491f0b3e.png";

export const Route = createFileRoute("/_site/about")({
  head: () => ({
    meta: [
      { title: "About — ModMax Technology" },
      {
        name: "description",
        content:
          "Meet ModMax Technology: a small studio of senior engineers, designers and architects helping startup founders launch products fast.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHeader
        eyebrow="About us"
        title="A studio built for people who ship."
        intro="ModMax Technology started in 2016 as two engineers tired of watching good product ideas die in slow agencies. Today we are a focused team of engineers, designers and cloud architects — still small on purpose."
      />

      <section className="nova-container border-b border-nova-line py-16 md:py-20">
        <div className="grid gap-10 md:grid-cols-12 md:items-center">
          <div className="md:col-span-6">
            <div className="overflow-hidden rounded-2xl border border-nova-line">
              <Image
                src={aboutImage}
                alt="Macro view of server cooling fins with a thin line of cyan light"
                className="h-64 w-full object-cover sm:h-80"
              />
            </div>
          </div>
          <div className="md:col-span-6 md:pl-6">
            <p className="eyebrow">Who we are</p>
            <p className="mt-5 text-base leading-relaxed text-nova-ink/90">
              We work as one embedded team: product thinking, interface design and backend engineering
              in the same conversation. That means fewer misunderstandings and a launch date you can
              plan a fundraise around.
            </p>
            <p className="mt-4 text-sm leading-relaxed text-nova-muted">
              Our stack stays deliberately boring where it matters — Java, Spring Boot, React and MySQL
              — so your first engineering hire can read the code, and your next round of investors can
              trust it.
            </p>
            <dl className="mt-8 grid grid-cols-2 gap-6">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <dt className="font-heading text-2xl font-semibold text-nova-ink">{stat.value}</dt>
                  <dd className="mt-1 text-[11px] uppercase tracking-[0.16em] text-nova-muted">
                    {stat.label}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <section className="nova-container border-b border-nova-line py-16 md:py-20">
        <p className="eyebrow">What drives us</p>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="nova-card p-8">
            <h2 className="font-heading text-lg font-semibold text-nova-ink">Mission</h2>
            <p className="mt-3 text-sm leading-relaxed text-nova-muted">{mission.mission}</p>
          </div>
          <div className="nova-card p-8">
            <h2 className="font-heading text-lg font-semibold text-nova-ink">Vision</h2>
            <p className="mt-3 text-sm leading-relaxed text-nova-muted">{mission.vision}</p>
          </div>
        </div>
      </section>

      <section className="nova-container border-b border-nova-line py-16 md:py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">The team</p>
            <h2 className="display mt-4 text-[clamp(1.7rem,3.4vw,2.6rem)]">
              The people you will actually work with
            </h2>
          </div>
          <p className="max-w-sm text-sm text-nova-muted">
            No account managers between you and the code — the people in your kickoff are the people
            building.
          </p>
        </div>
        <div className="mt-10">
          <TeamGrid />
        </div>
      </section>

      <div className="pt-16">
        <CtaBand />
      </div>
    </>
  );
}