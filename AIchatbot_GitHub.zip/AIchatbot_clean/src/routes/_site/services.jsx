import { createFileRoute } from "@tanstack/react-router";
import PageHeader from "@/components/site/PageHeader";
import ServiceSection from "@/components/services/ServiceSection";
import CtaBand from "@/components/home/CtaBand";
import { services } from "@/data/site";

export const Route = createFileRoute("/_site/services")({
  head: () => ({
    meta: [
      { title: "Services — ModMax Technology" },
      {
        name: "description",
        content:
          "Web development, app development, AI integration and cloud solutions from ModMax Technology — built for startup teams that need to launch fast.",
      },
    ],
  }),
  component: ServicesPage,
});

const process = [
  { step: "01", title: "Scope in a week", body: "A working session, then a written plan with fixed scope and dates." },
  { step: "02", title: "Build in increments", body: "Two-week demos you can click through, not status decks." },
  { step: "03", title: "Launch and hand over", body: "Deployment, monitoring, and documentation your team can run with." },
];

function ServicesPage() {
  return (
    <>
      <PageHeader
        eyebrow="Services"
        title="Four ways we get products shipped."
        intro="Every engagement is scoped around one goal: a working product in front of real users, without technical debt you have to repay at your next raise."
      />

      <div className="nova-container">
        {services.map((service, index) => (
          <ServiceSection key={service.id} service={service} index={index} />
        ))}
      </div>

      <section className="border-t border-nova-line bg-nova-soft/40 py-16 md:py-20">
        <div className="nova-container">
          <p className="eyebrow">How it runs</p>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {process.map((item) => (
              <div key={item.step} className="nova-card p-7">
                <span className="font-mono text-[11px] text-nova-accent-text">{item.step}</span>
                <h3 className="mt-4 font-heading text-lg font-semibold text-nova-ink">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-nova-muted">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="pt-16">
        <CtaBand />
      </div>
    </>
  );
}