import { createFileRoute } from "@tanstack/react-router";
import Hero from "@/components/site/Hero";
import Intro from "@/components/home/Intro";
import ServicesGrid from "@/components/home/ServicesGrid";
import WhyUs from "@/components/home/WhyUs";
import CtaBand from "@/components/home/CtaBand";

export const Route = createFileRoute("/_site/")({
  head: () => ({
    meta: [
      { title: "ModMax — Web, app, AI and cloud engineering" },
      {
        name: "description",
        content:
          "ModMax Technology is a software development studio building web platforms, mobile applications, AI integration and cloud solutions for startup founders.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <>
      <Hero />
      <Intro />
      <ServicesGrid />
      <WhyUs />
      <CtaBand />
    </>
  );
}