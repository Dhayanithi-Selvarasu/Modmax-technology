import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/config")({
  server: {
    handlers: {
      GET: async () =>
        Response.json({
          company: "ModMax Technology",
          assistant: "ModMax AI Assistant",
          chatbotEnabled: true,
          model: "gemini",
          email: "contact@modmaxtechnologies@gmail.com",
        }),
    },
  },
});