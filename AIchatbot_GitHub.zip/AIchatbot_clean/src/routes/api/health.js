import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () =>
        Response.json({
          status: "UP",
          message: "NOVA AI backend is running",
        }),
    },
  },
});